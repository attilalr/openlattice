# maybe we should move this to loader.tags since that's where all the constants
# are

MISSING_ICON = 'gazpacho-missing-icon'
STOCK_SIZEGROUP = 'gazpacho-sizegroup'
